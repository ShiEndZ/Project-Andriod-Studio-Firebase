package Profile

import android.app.DatePickerDialog
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.example.coffe.R
import java.util.*

@Composable
fun ProfileScreen(
    name: String,
    email: String,
    registerDate: String
) {

    var imageUri by remember { mutableStateOf<Uri?>(null) }
    var birthday by remember { mutableStateOf("Not set") }

    val context = LocalContext.current
    val calendar = Calendar.getInstance()

    val launcher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        imageUri = uri
    }

    val datePicker = DatePickerDialog(
        context,
        { _, year, month, day ->
            birthday = "$day/${month + 1}/$year"
        },
        calendar.get(Calendar.YEAR),
        calendar.get(Calendar.MONTH),
        calendar.get(Calendar.DAY_OF_MONTH)
    )

    Box(
        modifier = Modifier.fillMaxSize()
    ) {

        // Background Image
        Image(
            painter = painterResource(id = R.drawable.bg5),
            contentDescription = null,
            modifier = Modifier.fillMaxSize(),
            contentScale = ContentScale.Crop
        )

        Column(
            modifier = Modifier
                .fillMaxSize(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {

            Spacer(modifier = Modifier.height(40.dp))

            Text(
                text = "👤 Profile",
                style = MaterialTheme.typography.headlineMedium
            )

            Spacer(modifier = Modifier.height(30.dp))

            AsyncImage(
                model = imageUri ?: "https://cdn-icons-png.flaticon.com/512/3135/3135715.png",
                contentDescription = "Profile",
                modifier = Modifier
                    .size(150.dp)
                    .clip(CircleShape)
                    .clickable {
                        launcher.launch("image/*")
                    },
                contentScale = ContentScale.Crop
            )

            Spacer(modifier = Modifier.height(10.dp))

            Text("Tap to change photo")

            Spacer(modifier = Modifier.height(30.dp))

            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 24.dp),
                shape = RoundedCornerShape(20.dp)
            ) {

                Column(
                    modifier = Modifier.padding(24.dp)
                ) {

                    Text("Name")
                    Text(name)

                    Spacer(modifier = Modifier.height(12.dp))

                    Text("Email")
                    Text(email)

                    Spacer(modifier = Modifier.height(12.dp))

                    Text("Register Date")
                    Text(registerDate)

                    Spacer(modifier = Modifier.height(12.dp))

                    Text("Birthday")
                    Text(
                        birthday,
                        modifier = Modifier.clickable {
                            datePicker.show()
                        }
                    )

                }

            }

        }
    }
}