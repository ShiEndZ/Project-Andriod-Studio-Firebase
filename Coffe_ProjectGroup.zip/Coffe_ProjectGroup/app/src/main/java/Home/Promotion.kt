package Home

import androidx.annotation.DrawableRes

data class Promotion(
    val id: String,
    val title: String,
    @DrawableRes val image: Int,
    val description: String
)