package Home

import com.example.coffe.R

object PromotionData {

    val promotions = listOf(

        Promotion(
            id = "promo1",
            title = "Buy 1 Get 1 Free",
            image = R.drawable.promo1,
            description = "Buy 1 Get 1 Free for First-Time Customers!"
        ),

        Promotion(
            id = "promo2",
            title = "50% Off Coffee",
            image = R.drawable.promo2,
            description = "ลดครึ่งราคาเมื่อซื้อครั้งแรก"
        ),
                Promotion(
                id = "promo3",
        title = "Paired and bought cheaper",
        image = R.drawable.promo3,
        description = "ซื้อน้ำและอาหารทานเล่น รับส่วนลดไปเลย"
                ),
        Promotion(
                        id = "promo4",
        title = "มีให้ซื้อกลับบ้านแล้ว",
        image = R.drawable.promo4,
        description = "ซื้อแบบชงกลับบ้านได้ที่หน้าร้าน"

    )
    )

}