package Home

import android.content.Context

class RewardManager(context: Context) {

    private val prefs =
        context.getSharedPreferences("reward", Context.MODE_PRIVATE)

    fun getPoints(): Int {
        return prefs.getInt("points", 0)
    }

    fun addPoint() {

        val newPoints = getPoints() + 1

        prefs.edit()
            .putInt("points", newPoints)
            .apply()

    }

    fun resetPoints() {

        prefs.edit()
            .putInt("points", 0)
            .apply()

    }

}