package Home

import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.graphics.Color
import com.example.coffe.R

@Composable
fun HomeScreen(
    name: String = "Guest",
    email: String = "",
    photoUrl: String? = null,
    onRewardClick: () -> Unit,
    onPromotionClick: (Promotion) -> Unit
) {

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {

        // 🔹 Reward Banner
        Card(
            shape = RoundedCornerShape(20.dp),
            elevation = CardDefaults.cardElevation(8.dp),
            modifier = Modifier
                .fillMaxWidth()
                .height(180.dp)
                .clickable { onRewardClick() }
        ) {

            Box {

                Image(
                    painter = painterResource(id = R.drawable.reward_banner),
                    contentDescription = "Reward",
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )

                Column(
                    modifier = Modifier
                        .align(Alignment.BottomStart)
                        .padding(16.dp)
                ) {

                    Text(
                        text = "⭐ Coffee Rewards",
                        style = MaterialTheme.typography.headlineSmall,
                        color = Color.White
                    )

                    Spacer(modifier = Modifier.height(4.dp))

                    Text(
                        text = "Collect points and get free coffee!",
                        style = MaterialTheme.typography.bodyMedium,
                        color = Color.White
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // 🔹 Popular Menu
        Text(
            text = "Popular Menu",
            style = MaterialTheme.typography.titleLarge
        )

        Spacer(modifier = Modifier.height(12.dp))

        Row(
            horizontalArrangement = Arrangement.SpaceBetween,
            modifier = Modifier.fillMaxWidth()
        ) {

            MenuItem("Latte", R.drawable.latte)
            MenuItem("Cappuccino", R.drawable.cappuccino)
            MenuItem("Mocha", R.drawable.mocha)

        }

        Spacer(modifier = Modifier.height(24.dp))


        Text(
            text = "🔥 New Promotion",
            style = MaterialTheme.typography.titleLarge
        )

        Spacer(modifier = Modifier.height(12.dp))

        LazyRow {

            items(PromotionData.promotions) { promo ->

                PromotionCard(
                    promotion = promo,
                    onClick = { onPromotionClick(promo) }
                )

            }

        }

    }

}

@Composable
fun MenuItem(
    name: String,
    image: Int
) {

    Column(
        horizontalAlignment = Alignment.CenterHorizontally
    ) {

        Card(
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier.size(90.dp)
        ) {

            Image(
                painter = painterResource(id = image),
                contentDescription = name,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )

        }

        Spacer(modifier = Modifier.height(6.dp))

        Text(text = name)

    }

}