package Home

import android.content.Context
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import Home.RewardManager

@Composable
fun RewardScreen(
    context: Context,
    onBack: () -> Unit
) {


    val rewardManager = RewardManager(context)

    var points by remember {
        mutableStateOf(rewardManager.getPoints())
    }

    val progress by animateFloatAsState(
        targetValue = points / 10f,
        label = "progress"
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(20.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {

        Text(
            text = "⭐ Coffee Rewards",
            style = MaterialTheme.typography.headlineMedium
        )

        Spacer(modifier = Modifier.height(20.dp))

        // ⭐ Progress Bar
        LinearProgressIndicator(
            progress = progress,
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(10.dp))

        Text("$points / 10 Stars")

        Spacer(modifier = Modifier.height(30.dp))

        // ⭐ ดาวสะสม
        Row {

            repeat(10) { index ->

                val filled = index < points

                Box(
                    modifier = Modifier
                        .size(30.dp)
                        .padding(4.dp)
                        .background(
                            if (filled) Color(0xFFFFC107)
                            else Color.LightGray,
                            CircleShape
                        )
                )

            }

        }

        Spacer(modifier = Modifier.height(40.dp))

        // ⭐ ปุ่มเพิ่มดาว
        Button(
            onClick = {

                rewardManager.addPoint()

                points = rewardManager.getPoints()

            }
        ) {

            Text("Drink Coffee ☕")

        }

        Spacer(modifier = Modifier.height(20.dp))

        // ⭐ ถ้าแต้มครบ 10 ให้ใช้คูปอง
        if (points >= 10) {

            Button(
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color(0xFF4CAF50)
                ),
                onClick = {

                    rewardManager.resetPoints()

                    points = rewardManager.getPoints()

                }
            ) {

                Text("🎉 Use Free Coffee Coupon")

            }

        }

        Spacer(modifier = Modifier.height(20.dp))

        Button(
            onClick = { onBack() }
        ) {

            Text("Back")

        }

    }

}