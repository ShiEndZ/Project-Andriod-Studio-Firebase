package MenuScreen

import CartScreen.CartItem
import androidx.compose.runtime.mutableStateListOf

object CartManager {

    val cartItems = mutableStateListOf<CartItem>()

    fun addToCart(drink: CoffeeMenu, quantity: Int = 1, note: String = "") {

        val existing = cartItems.find {
            it.drink.name == drink.name
        }

        if (existing != null) {

            existing.quantity += quantity
            existing.note = note

        } else {

            cartItems.add(
                CartItem(drink, quantity).apply {
                    this.note = note
                }
            )

        }

    }

    fun removeItem(item: CartItem) {
        cartItems.remove(item)
    }

    fun clearCart() {
        cartItems.clear()
    }
}