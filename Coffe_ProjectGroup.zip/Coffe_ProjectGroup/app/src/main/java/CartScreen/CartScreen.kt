package CartScreen

import MenuScreen.CartManager
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import HistoryScreen.HistoryManager
import com.google.firebase.firestore.FirebaseFirestore
import java.util.UUID

@Composable
fun CartScreen() {

    val cartItems = CartManager.cartItems

    val totalPrice = cartItems.sumOf { item ->
        val price = item.drink.price
            .replace("THB", "")
            .trim()
            .toInt()

        price * item.quantity
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {

        Text(
            text = "🛒 Cart",
            style = MaterialTheme.typography.headlineMedium
        )

        Spacer(modifier = Modifier.height(16.dp))

        LazyColumn(
            modifier = Modifier.weight(1f)
        ) {

            items(cartItems) { item ->

                val price = item.drink.price
                    .replace("THB", "")
                    .trim()
                    .toInt()

                val itemTotal = price * item.quantity

                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 10.dp)
                ) {

                    Column(
                        modifier = Modifier.padding(12.dp)
                    ) {

                        Row(
                            verticalAlignment = Alignment.CenterVertically
                        ) {

                            Image(
                                painter = painterResource(id = item.drink.image),
                                contentDescription = item.drink.name,
                                modifier = Modifier.size(70.dp)
                            )

                            Spacer(modifier = Modifier.width(12.dp))

                            Column(
                                modifier = Modifier.weight(1f)
                            ) {

                                Text(item.drink.name)
                                Text("Quantity: ${item.quantity}")
                                Text("Total: $itemTotal THB")

                            }

                            Column {

                                Button(
                                    onClick = { item.quantity++ }
                                ) {
                                    Text("+")
                                }

                                Spacer(modifier = Modifier.height(6.dp))

                                Button(
                                    onClick = {

                                        if (item.quantity > 1) {
                                            item.quantity--
                                        } else {
                                            CartManager.cartItems.remove(item)
                                        }

                                    }
                                ) {
                                    Text("-")
                                }

                            }

                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        // ช่อง Note
                        OutlinedTextField(
                            value = item.note,
                            onValueChange = { item.note = it },
                            label = { Text("Note") },
                            placeholder = { Text("เช่น ไม่หวาน / ไม่ใส่น้ำแข็ง") },
                            modifier = Modifier.fillMaxWidth()
                        )

                    }

                }

            }

        }

        Divider()

        Spacer(modifier = Modifier.height(10.dp))

        Text(
            text = "Total Price: $totalPrice THB",
            style = MaterialTheme.typography.headlineSmall
        )

        Spacer(modifier = Modifier.height(10.dp))

        Button(
            onClick = {

                val db = FirebaseFirestore.getInstance()

                val orderId = UUID.randomUUID().toString()

                val orderData = hashMapOf(
                    "orderId" to orderId,
                    "items" to cartItems.map {

                        hashMapOf(
                            "name" to it.drink.name,
                            "quantity" to it.quantity,
                            "price" to it.drink.price,
                            "image" to it.drink.image,
                            "note" to it.note
                        )

                    },
                    "totalPrice" to totalPrice,
                    "time" to System.currentTimeMillis()
                )

                db.collection("orders")
                    .document(orderId)
                    .set(orderData)
                    .addOnSuccessListener {

                        HistoryManager.addOrder(
                            orderId,
                            cartItems.toList(),
                            totalPrice
                        )

                        CartManager.cartItems.clear()

                    }

            },
            modifier = Modifier.fillMaxWidth()
        ) {

            Text("Checkout")

        }

    }

}