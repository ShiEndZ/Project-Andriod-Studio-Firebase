package CartScreen

import CartScreen.CartItem
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@Composable
fun CartItemView(item: CartItem) {

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(8.dp)
    ) {

        Column(
            modifier = Modifier.padding(16.dp)
        ) {

            Text(
                text = item.drink.name,
                style = MaterialTheme.typography.titleMedium
            )

            Spacer(modifier = Modifier.height(8.dp))

            Text(text = "จำนวน: ${item.quantity}")

            Spacer(modifier = Modifier.height(8.dp))

            OutlinedTextField(
                value = item.note,
                onValueChange = { item.note = it },
                label = { Text("หมายเหตุ") },
                placeholder = { Text("เช่น ไม่หวาน / ไม่ใส่น้ำแข็ง") },
                modifier = Modifier.fillMaxWidth()
            )

        }
    }
}