package CartScreen

import MenuScreen.CoffeeMenu
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue

class CartItem(
    val drink: CoffeeMenu,
    quantity: Int,
    note: String = ""
) {

    var quantity by mutableStateOf(quantity)

    var note by mutableStateOf(note)

}