package HistoryScreen

import CartScreen.CartItem
import MenuScreen.CoffeeMenu
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import com.google.firebase.firestore.FirebaseFirestore

@Composable
fun HistoryScreen() {

    val historyList = HistoryManager.historyList
    val db = FirebaseFirestore.getInstance()

    LaunchedEffect(Unit) {

        if (historyList.isEmpty()) {

            db.collection("orders")
                .get()
                .addOnSuccessListener { result ->

                    for (document in result) {

                        val totalPrice =
                            document.getLong("totalPrice")?.toInt() ?: 0

                        val itemsData =
                            document.get("items") as? List<Map<String, Any>>
                                ?: emptyList()

                        val items = itemsData.mapNotNull { item ->

                            val name =
                                item["name"] as? String ?: return@mapNotNull null

                            val price =
                                item["price"] as? String ?: "0"

                            val quantity =
                                (item["quantity"] as? Long)?.toInt() ?: 1

                            val image =
                                (item["image"] as? Long)?.toInt()
                                    ?: return@mapNotNull null

                            val note =
                                item["note"] as? String ?: ""

                            val drink = CoffeeMenu(
                                name = name,
                                price = price,
                                image = image
                            )


                            CartItem(drink, quantity, note)

                        }

                        HistoryManager.addOrder(
                            document.id,
                            items,
                            totalPrice
                        )

                    }

                }

        }

    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {

        Text(
            text = "📜 Order History",
            style = MaterialTheme.typography.headlineMedium
        )

        Spacer(modifier = Modifier.height(16.dp))

        LazyColumn {

            items(historyList) { order ->

                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 12.dp)
                ) {

                    Column(
                        modifier = Modifier.padding(12.dp)
                    ) {

                        order.items.forEach { item ->

                            val price = item.drink.price
                                .replace("THB", "")
                                .trim()
                                .toInt()

                            val total = price * item.quantity

                            Row(
                                verticalAlignment = Alignment.CenterVertically
                            ) {

                                Image(
                                    painter = painterResource(id = item.drink.image),
                                    contentDescription = item.drink.name,
                                    modifier = Modifier.size(60.dp)
                                )

                                Spacer(modifier = Modifier.width(12.dp))

                                Column(
                                    modifier = Modifier.weight(1f)
                                ) {

                                    Text(item.drink.name)
                                    Text("Quantity : ${item.quantity}")
                                    Text("Total : $total THB")

                                    // ✅ แสดง Note (อ่านได้อย่างเดียว)
                                    if (item.note.isNotEmpty()) {
                                        Text("Note : ${item.note}")
                                    }

                                }

                            }

                            Spacer(modifier = Modifier.height(8.dp))

                        }

                        Divider()

                        Spacer(modifier = Modifier.height(6.dp))

                        Text(
                            text = "Total Order : ${order.totalPrice} THB"
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        Button(
                            onClick = {

                                db.collection("orders")
                                    .document(order.orderId)
                                    .delete()

                                HistoryManager.removeOrder(order)

                            },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("Delete")
                        }

                    }

                }

            }

        }

    }

}