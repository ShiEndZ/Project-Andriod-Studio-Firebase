package HistoryScreen

import CartScreen.CartItem

data class OrderHistory(
    val orderId: String,
    val items: List<CartItem>,
    val totalPrice: Int
)