package HistoryScreen

import CartScreen.CartItem
import androidx.compose.runtime.mutableStateListOf

object HistoryManager {

    val historyList = mutableStateListOf<OrderHistory>()

    fun addOrder(
        orderId: String,
        items: List<CartItem>,
        totalPrice: Int
    ) {

        val newOrder = OrderHistory(
            orderId = orderId,

            // ✅ copy note ไปด้วย
            items = items.map {
                CartItem(
                    drink = it.drink,
                    quantity = it.quantity,
                    note = it.note
                )
            },

            totalPrice = totalPrice
        )

        historyList.add(0, newOrder)
    }

    fun removeOrder(order: OrderHistory) {
        historyList.remove(order)
    }

}