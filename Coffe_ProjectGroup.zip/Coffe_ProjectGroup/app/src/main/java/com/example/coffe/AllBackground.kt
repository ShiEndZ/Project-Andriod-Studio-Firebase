package Home

import com.example.coffe.R

data class AllBackground(
    val imageRes: Int
)

val allBackgroundList = listOf(
    AllBackground(R.drawable.bg2)
)