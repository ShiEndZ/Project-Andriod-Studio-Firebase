package com.example.coffe

import MenuScreen.CartManager
import CartScreen.CartScreen
import HistoryScreen.HistoryScreen
import Home.HomeScreen
import Home.Promotion
import Home.PromotionDetailScreen
import Home.RewardScreen
import Home.allBackgroundList
import MakePasswordLogin.LoginScreen
import MakePasswordLogin.RegisterScreen
import MakePasswordLogin.TermScreen
import MenuScreen.CoffeeMenu
import MenuScreen.DetailDrinkScreen
import MenuScreen.MenuScreen
import Profile.ProfileScreen
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.*
import androidx.compose.material3.*
import androidx.compose.ui.Modifier
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.platform.LocalContext
import com.example.coffe.ui.theme.CoffeTheme
import com.google.firebase.auth.FirebaseAuth
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
class MainActivity : ComponentActivity() {

    private lateinit var auth: FirebaseAuth

    override fun onCreate(savedInstanceState: Bundle?) {

        super.onCreate(savedInstanceState)

        auth = FirebaseAuth.getInstance()

        enableEdgeToEdge()

        setContent {

            CoffeTheme {

                val context = LocalContext.current

                Box {

                    Image(
                        painter = painterResource(id = allBackgroundList[0].imageRes),
                        contentDescription = "Background",
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Crop
                    )

                    var showRegister by remember { mutableStateOf(false) }
                    var showLogin by remember { mutableStateOf(false) }
                    var showReward by remember { mutableStateOf(false) }
                    var showTerm by remember { mutableStateOf(false) }

                    var showPromotion by remember { mutableStateOf(false) }
                    var selectedPromo by remember { mutableStateOf<Promotion?>(null) }

                    var isLoggedIn by remember {
                        mutableStateOf(auth.currentUser != null)
                    }

                    var selectedTab by remember { mutableStateOf(0) }

                    var selectedDrink by remember { mutableStateOf<CoffeeMenu?>(null) }

                    Scaffold(

                        containerColor = Color.Transparent,

                        topBar = {

                            TopAppBar(

                                colors = TopAppBarDefaults.topAppBarColors(
                                    containerColor = Color(0xFF6F4E37),
                                    titleContentColor = Color.White
                                ),

                                title = {

                                    Text(
                                        text = "☕ Coffee App",
                                        modifier = Modifier.clickable {

                                            showLogin = false
                                            showRegister = false
                                            showReward = false
                                            showPromotion = false
                                            showTerm = false
                                            selectedDrink = null
                                            selectedTab = 0

                                        }
                                    )

                                },

                                actions = {

                                    if (isLoggedIn) {

                                        val currentUser = auth.currentUser
                                        val name = currentUser?.displayName ?: "User"

                                        Row(
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {

                                            Icon(
                                                imageVector = Icons.Default.Person,
                                                contentDescription = "Profile",
                                                tint = Color.White
                                            )

                                            Text(
                                                text = name,
                                                color = Color.White,
                                                modifier = Modifier.padding(
                                                    start = 4.dp,
                                                    end = 10.dp
                                                )
                                            )

                                            TextButton(
                                                onClick = {

                                                    auth.signOut()

                                                    isLoggedIn = false
                                                    showLogin = false
                                                    showRegister = false
                                                    selectedTab = 0

                                                }
                                            ) {

                                                Text(
                                                    text = "Logout",
                                                    color = Color.White
                                                )

                                            }

                                        }

                                    } else {

                                        TextButton(
                                            onClick = {

                                                showLogin = true
                                                showRegister = false

                                            }
                                        ) {

                                            Text(
                                                text = "Login",
                                                color = Color.White
                                            )

                                        }

                                    }

                                }

                            )

                        },

                        bottomBar = {

                            if (isLoggedIn) {

                                NavigationBar {

                                    NavigationBarItem(
                                        selected = selectedTab == 0,
                                        onClick = {
                                            selectedTab = 0
                                            showReward = false
                                            showPromotion = false
                                            selectedDrink = null
                                        },
                                        icon = { Icon(Icons.Default.Home, "Home") },
                                        label = { Text("Home") }
                                    )

                                    NavigationBarItem(
                                        selected = selectedTab == 1,
                                        onClick = {
                                            selectedTab = 1
                                            selectedDrink = null
                                        },
                                        icon = { Icon(Icons.Default.Menu, "Menu") },
                                        label = { Text("Menu") }
                                    )

                                    NavigationBarItem(
                                        selected = selectedTab == 2,
                                        onClick = { selectedTab = 2 },
                                        icon = { Icon(Icons.Default.ShoppingCart, "Cart") },
                                        label = { Text("Cart") }
                                    )

                                    NavigationBarItem(
                                        selected = selectedTab == 3,
                                        onClick = { selectedTab = 3 },
                                        icon = { Icon(Icons.Default.History, "History") },
                                        label = { Text("History") }
                                    )

                                    NavigationBarItem(
                                        selected = selectedTab == 4,
                                        onClick = { selectedTab = 4 },
                                        icon = { Icon(Icons.Default.Person, "Profile") },
                                        label = { Text("Profile") }
                                    )

                                }

                            }

                        }

                    ) { padding ->

                        Surface(
                            modifier = Modifier.padding(padding),
                            color = Color.Transparent
                        ) {

                            when {

                                selectedDrink != null -> {

                                    DetailDrinkScreen(
                                        drink = selectedDrink!!,
                                        onBack = { selectedDrink = null },
                                        onBuy = { drink, quantity, note ->

                                            CartManager.addToCart(drink, quantity, note)

                                            selectedDrink = null
                                            selectedTab = 2

                                        }
                                    )

                                }

                                showTerm -> {
                                    TermScreen()
                                }

                                showReward -> {

                                    RewardScreen(
                                        context = context,
                                        onBack = { showReward = false }
                                    )

                                }

                                showPromotion && selectedPromo != null -> {

                                    PromotionDetailScreen(
                                        promotion = selectedPromo!!,
                                        onBack = { showPromotion = false }
                                    )

                                }

                                isLoggedIn -> {

                                    val currentUser = auth.currentUser

                                    val registerDate =
                                        currentUser?.metadata?.creationTimestamp?.let {

                                            SimpleDateFormat(
                                                "dd/MM/yyyy",
                                                Locale.getDefault()
                                            ).format(Date(it))

                                        } ?: "Unknown"

                                    when (selectedTab) {

                                        0 -> {

                                            HomeScreen(
                                                name = currentUser?.displayName ?: "User",
                                                email = currentUser?.email ?: "",
                                                photoUrl = currentUser?.photoUrl?.toString(),
                                                onRewardClick = { showReward = true },
                                                onPromotionClick = { promo ->
                                                    selectedPromo = promo
                                                    showPromotion = true
                                                }
                                            )

                                        }

                                        1 -> {

                                            MenuScreen(
                                                onDrinkSelected = { drink ->
                                                    selectedDrink = drink
                                                }
                                            )

                                        }

                                        2 -> CartScreen()

                                        3 -> HistoryScreen()

                                        4 -> {

                                            ProfileScreen(
                                                name = currentUser?.displayName ?: "User",
                                                email = currentUser?.email ?: "",
                                                registerDate = registerDate
                                            )

                                        }

                                    }

                                }

                                showRegister -> {

                                    RegisterScreen(
                                        auth = auth,
                                        onBackToLogin = {

                                            showRegister = false
                                            showLogin = true

                                        }
                                    )

                                }

                                showLogin -> {

                                    LoginScreen(
                                        auth = auth,

                                        onRegisterClick = {

                                            showRegister = true
                                            showLogin = false

                                        },

                                        onLoginSuccess = {

                                            isLoggedIn = true

                                        },

                                        onTermClick = {

                                            showTerm = true
                                            showLogin = false

                                        }

                                    )

                                }

                                else -> {

                                    HomeScreen(
                                        name = "Guest",
                                        email = "",
                                        photoUrl = null,
                                        onRewardClick = {},
                                        onPromotionClick = {}
                                    )

                                }

                            }

                        }

                    }

                }

            }

        }

    }

}