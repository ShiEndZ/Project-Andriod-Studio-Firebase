package com.example.coffe.ui.theme

data class Order(
    val id: String = "",
    val size: String = "",
    val qty: Int = 0,
    val note: String? = null
)