package MenuScreen

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp

@Composable
fun DetailDrinkScreen(
    drink: CoffeeMenu,
    onBack: () -> Unit,
    onBuy: (CoffeeMenu, Int, String) -> Unit
) {

    var quantity by remember { mutableStateOf(1) }
    var note by remember { mutableStateOf("") }

    Column(
        modifier = Modifier.fillMaxSize()
    ) {

        // รูปใหญ่
        Image(
            painter = painterResource(id = drink.image),
            contentDescription = drink.name,
            modifier = Modifier
                .fillMaxWidth()
                .height(260.dp),
            contentScale = ContentScale.Crop
        )

        Spacer(modifier = Modifier.height(20.dp))

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp)
        ) {

            Text(
                text = drink.name,
                style = MaterialTheme.typography.headlineSmall
            )

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = "Price : ${drink.price}",
                style = MaterialTheme.typography.titleMedium
            )

        }

        Spacer(modifier = Modifier.height(30.dp))

        // ปุ่ม + -
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically
        ) {

            IconButton(
                onClick = {
                    if (quantity > 1) quantity--
                }
            ) {
                Icon(Icons.Default.Remove, contentDescription = "Minus")
            }

            Text(
                text = quantity.toString(),
                style = MaterialTheme.typography.headlineMedium,
                modifier = Modifier.padding(horizontal = 20.dp)
            )

            IconButton(
                onClick = { quantity++ }
            ) {
                Icon(Icons.Default.Add, contentDescription = "Plus")
            }

        }

        Spacer(modifier = Modifier.height(16.dp))

        // ช่องพิมพ์ข้อความ
        OutlinedTextField(
            value = note,
            onValueChange = { note = it },
            label = { Text("Note") },
            placeholder = { Text("เช่น ไม่หวาน / ไม่ใส่น้ำแข็ง") },
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp)
        )

        Spacer(modifier = Modifier.weight(1f))

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {

            Button(
                onClick = onBack,
                modifier = Modifier
                    .weight(1f)
                    .height(55.dp),
                shape = RoundedCornerShape(12.dp)
            ) {
                Text("Back")
            }

            Spacer(modifier = Modifier.width(16.dp))

            Button(
                onClick = {
                    onBuy(drink, quantity, note)
                },
                modifier = Modifier
                    .weight(1f)
                    .height(55.dp),
                shape = RoundedCornerShape(12.dp)
            ) {
                Text("Buy")
            }

        }

    }

}