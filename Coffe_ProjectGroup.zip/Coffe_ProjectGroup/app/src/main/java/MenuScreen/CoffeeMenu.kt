package MenuScreen

data class CoffeeMenu(
    val name: String,
    val price: String,
    val image: Int
)