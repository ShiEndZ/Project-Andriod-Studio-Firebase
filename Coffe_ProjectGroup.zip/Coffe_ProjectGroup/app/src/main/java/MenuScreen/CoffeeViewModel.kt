package MenuScreen

import androidx.lifecycle.ViewModel
import com.example.coffe.R
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

class CoffeeViewModel : ViewModel() {

    private val _menuList = MutableStateFlow(
        listOf(
            CoffeeMenu("Latte", "80 THB", R.drawable.latte),
            CoffeeMenu("Cappuccino", "85 THB", R.drawable.cappuccino),
            CoffeeMenu("Mocha", "90 THB", R.drawable.mocha),
            CoffeeMenu("Americano", "70 THB", R.drawable.americano),
            CoffeeMenu("Espresso", "60 THB", R.drawable.espresso),
            CoffeeMenu("Green tea", "55 THB", R.drawable.greentea),
            CoffeeMenu("Lemon tea", "45 THB", R.drawable.lemontea),
            CoffeeMenu("Matcha latte", "90 THB", R.drawable.matchalatte),
            CoffeeMenu("Macchiato", "85 THB", R.drawable.macchiato),
            CoffeeMenu("Chocolate Yen", "50 THB", R.drawable.chocolateyen),
            CoffeeMenu("Chocolate cake", "120 THB", R.drawable.chocolatecake),
            CoffeeMenu("vanilla cake", "120 THB", R.drawable.vanillacake),
            CoffeeMenu("strawberry cake", "120 THB", R.drawable.strawberrycake),
            CoffeeMenu("egg tart", "35 THB", R.drawable.eggtart),
            CoffeeMenu("Donut", "25 THB", R.drawable.donut),
        )
    )

    val menuList: StateFlow<List<CoffeeMenu>> = _menuList
}