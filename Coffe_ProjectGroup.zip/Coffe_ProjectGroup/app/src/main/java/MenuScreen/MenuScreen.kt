package MenuScreen

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MenuScreen(
    onDrinkSelected: (CoffeeMenu) -> Unit,
    viewModel: CoffeeViewModel = viewModel()
) {

    val menuList by viewModel.menuList.collectAsState()

    Scaffold(

        topBar = {
            TopAppBar(
                title = { Text("☕ Coffee Menu") }
            )
        }

    ) { padding ->

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {

            items(menuList) { menu ->
                MenuCard(menu, onDrinkSelected)
            }

        }

    }

}

@Composable
fun MenuCard(
    menu: CoffeeMenu,
    onDrinkSelected: (CoffeeMenu) -> Unit
) {

    Card(
        shape = RoundedCornerShape(16.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 6.dp),
        modifier = Modifier.fillMaxWidth()
    ) {

        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {

            Image(
                painter = painterResource(id = menu.image),
                contentDescription = menu.name,
                modifier = Modifier.size(80.dp),
                contentScale = ContentScale.Crop
            )

            Spacer(modifier = Modifier.width(16.dp))

            Column(
                modifier = Modifier.weight(1f)
            ) {

                Text(
                    text = menu.name,
                    style = MaterialTheme.typography.titleMedium
                )

                Text(
                    text = menu.price,
                    style = MaterialTheme.typography.bodyMedium
                )

            }

            Button(
                onClick = {
                    onDrinkSelected(menu)
                }
            ) {
                Text("Add")
            }

        }

    }

}