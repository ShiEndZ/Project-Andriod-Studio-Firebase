package MakePasswordLogin

import android.content.Context
import android.util.Log
import androidx.credentials.CredentialManager
import androidx.credentials.GetCredentialRequest
import androidx.credentials.CustomCredential
import com.google.android.libraries.identity.googleid.GetSignInWithGoogleOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.GoogleAuthProvider
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

fun loginWithGoogle(
    context: Context,
    auth: FirebaseAuth,
    onLoginSuccess: () -> Unit
) {

    val credentialManager = CredentialManager.create(context)

    val googleOption = GetSignInWithGoogleOption.Builder(
        "YOUR_WEB_CLIENT_ID"   // 🔴 เปลี่ยนเป็น Web Client ID จาก Firebase
    ).build()

    val request = GetCredentialRequest.Builder()
        .addCredentialOption(googleOption)
        .build()

    CoroutineScope(Dispatchers.Main).launch {

        try {

            val result = credentialManager.getCredential(
                context = context,
                request = request
            )

            val credential = result.credential

            if (credential is CustomCredential &&
                credential.type == GoogleIdTokenCredential.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL
            ) {

                val googleIdTokenCredential =
                    GoogleIdTokenCredential.createFrom(credential.data)

                val idToken = googleIdTokenCredential.idToken

                val firebaseCredential =
                    GoogleAuthProvider.getCredential(idToken, null)

                auth.signInWithCredential(firebaseCredential)
                    .addOnCompleteListener { task ->

                        if (task.isSuccessful) {

                            Log.d("LOGIN", "Google Login Success")

                            onLoginSuccess()

                        } else {

                            Log.e("LOGIN", "Firebase Login Failed", task.exception)

                        }

                    }
            }

        } catch (e: Exception) {

            Log.e("LOGIN", "Google Login Error: ${e.message}")

        }

    }
}