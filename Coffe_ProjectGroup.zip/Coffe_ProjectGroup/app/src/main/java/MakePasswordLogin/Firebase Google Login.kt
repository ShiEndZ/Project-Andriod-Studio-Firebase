package MakePasswordLogin

import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.GoogleAuthProvider

fun firebaseAuthWithGoogle(
    idToken: String,
    auth: FirebaseAuth,
    onLoginSuccess: () -> Unit
) {

    val credential = GoogleAuthProvider.getCredential(idToken, null)

    auth.signInWithCredential(credential)
        .addOnCompleteListener { task ->

            if (task.isSuccessful) {

                println("Google Login Success")
                onLoginSuccess()

            } else {

                println("Google Login Failed")

            }

        }
}