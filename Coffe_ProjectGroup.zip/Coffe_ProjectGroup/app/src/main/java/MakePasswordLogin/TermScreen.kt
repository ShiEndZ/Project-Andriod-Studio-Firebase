package MakePasswordLogin

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.coffe.R

@Composable
fun TermScreen() {

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(20.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color(0xFFEFEFEF), RoundedCornerShape(16.dp))
                .padding(24.dp)
        ) {

            Column {

                Text(
                    text = "สมาชิกกลุ่ม",
                    fontSize = 56.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(bottom = 20.dp)
                )

                MemberItem("กิตติวินท์ ตรีศิริลาภ", "6630250036")
                Spacer(modifier = Modifier.height(12.dp))

                MemberItem("ชลสิทธิ์ สิงห์เรือง", "6630250061")
                Spacer(modifier = Modifier.height(12.dp))

                MemberItem("ณัฐนนท์ ถาวร", "6630250095")
                Spacer(modifier = Modifier.height(12.dp))

                MemberItem("วุฒิภัทร ใจก้อน", "6630250451")

            }
        }

        Spacer(modifier = Modifier.height(600.dp))

        Image(
            painter = painterResource(id = R.drawable.ete1),
            contentDescription = "Term Image",
            modifier = Modifier
                .fillMaxWidth()
                .height(200.dp)
        )

        Spacer(modifier = Modifier.height(40.dp))
    }
}

@Composable
fun MemberItem(name: String, id: String) {
    Column {
        Text(
            text = name,
            fontSize = 32.sp,
            fontWeight = FontWeight.SemiBold
        )

        Text(
            text = id,
            fontSize = 26.sp,
            color = Color.DarkGray
        )
    }
}